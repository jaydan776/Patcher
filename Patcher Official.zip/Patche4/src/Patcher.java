/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */





/**
 *
 * @author jacob
 */
public class Patcher  {
    
    private int id;
    private String name;
    private String url;
    private String version;
    private String description;;
        
public  Patcher(int id, String name, String url, String version,
			String description) {
	
		this.id = id;
		this.name = name;
		this.url = url;
		this.version = version;
		this.description = description;
                
	}

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @return the url
     */
    public String getUrl() {
        return url;
    }

    /**
     * @return the version
     */
    public String getVersion() {
        return version;
    }

    /**
     * @return the description
     */
    public String getDescription() {
        return description;
    }

    
    }
  
   

   
    
    



